<?php
$name = $_POST["name"];
 $email = $_POST["email"];
  $contact = $_POST["contact"];
  $state= $_POST["state"];
  $loginurname= $_POST["loginurname"];

  

  // Database connection
  $conn = new mysqli('localhost','root','','cpp_db');
  if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
  } else {
    $stmt = $conn->prepare("insert into tb_db(name, email, contact, state, loginurname) values(?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $contact, $state, $loginurname);
    $execval = $stmt->execute();
    echo $execval;
    echo
  "
  <script> alert('Registration Successfully'); </script>
  ";
    $stmt->close();
    $conn->close();
  }
?>
