
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Insert Data</title>
  </head>
  <style media="screen">
    label{
      display: block;
    }
  </style>
  <body>
         <form action="connection.php" method="post">



  <link rel="stylesheet"href="style.css"type="text/css">
</head>
<body style="background:url('white')">
</body>
  <div class="main">
    <div class="register">
    <center>
      <h1>Car Registration Form</h1>
      <form id="register" method="post">
        <h2>Name:<h2>
                        <br>
                       <input type="text" name="name" placeholder="Enter Your Name">

                                             <br>
        <h2>Email Id:</h2>
        <br>
        <input type="email" name="email" id="name" placeholder="Enter Your Valid Email Id">
        <br>
        <h2>Contact:</h2>
        <br>
        <input type="number" name="contact" id="name" placeholder="Enter Your Valid contact Number">
                                       <br>
         <h2>State</h2>
                                         <br>
      <input type="radio" name="state" value="maharashtra" required> Maharashtra
      <input type="radio" name="state" value="other"> Other
        <br>
      <h2>Login Time Username</h2>
      <input type="text" name="loginurname" id="name" placeholder="Enter Your  Login Time Username">
      <br>
      <br>
        <input type="submit" value="submit" name="submit"id="submit">
      </center>
      </form>
    </div><!--end register-->
  </div><!--end main-->
</html>